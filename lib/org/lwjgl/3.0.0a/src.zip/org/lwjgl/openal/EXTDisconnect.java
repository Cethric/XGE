/*
 * Copyright LWJGL. All rights reserved.
 * License terms: http://lwjgl.org/license.php
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.openal;

/** bindings to ALC_EXT_disconnect extension. */
public final class EXTDisconnect {

	/** ALC_EXT_disconnect tokens. */
	public static final int ALC_CONNECTED  = 0x313;

	private EXTDisconnect() {}

}